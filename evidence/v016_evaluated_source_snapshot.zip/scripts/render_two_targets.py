"""Computed before/after raw detection versus alarm-holding report."""
import json
from pathlib import Path
from html import escape

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/two_target_improvement'
def read(n):return json.loads((OUT/n).read_bytes())
def pc(x):return '산출 불가' if x is None else f'{100*x:.4f}%'
def tab(h,rows):return '| '+' | '.join(h)+' |\n| '+' | '.join(['---']*len(h))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)+'\n'
def table(records,delay_key='delay'):
    rows=[]
    for name,v in records.items():
        m=v['metrics'];d=v[delay_key]
        delay='시작 전 활성 경보 '+str(d['already_active_at_onset'])+'구간; 전체 지연 비교 보류' if d['already_active_at_onset'] else ('미검출' if d['max_delay_s'] is None else f"{d['max_delay_s']:.0f}초")
        rows.append([name,*[pc(m[k]) for k in ('accuracy_valid','recall_valid','false_positive_rate_valid','coverage')],delay])
    return tab(['정책','정확도','검출률/경보 상태 비율','오경보율','대상 판단률','최대 관측 지연'],rows)

def main():
    a=read('assessment.json');r=read('results.json');audit=read('independent_audit.json');manifest=read('marine_added_normal_manifest.json')
    assert audit['successful']
    text='# 엔진 필터 → EF10.1 초기 검출 → 경보 유지 검증 (v0.16.0, 2026-11-06)\n\n'
    text+='엔진 필터 정상 기준 보완, 히트펌프의 추가 원시 판정 경로, 경보 해제 지연을 순서대로 구현·검증했다. **평가 자료는 기존 실제 실험을 재사용했으며 새 독립 고장 검증은 없다.** 기존 외부 학습/보정/평가 행 분리는 그대로 두고, 엔진의 이전 미사용 정상 파일을 학습·보정에만 추가했다.\n\n'
    text+='EF10.1은 추가 응답 지표로 재사용 표본의 원시 판별력이 개선됐다. **유량 감소 원인에 특이적인 검출력이나 다른 날짜·설비의 성능을 입증한 결과는 아니다.** 엔진 필터 후보는 오경보가 증가해 미채택했다. 경보 유지 효과는 원시 검출 표와 분리했다.\n\n'
    text+='## 1. 엔진 필터 정상 기준\n\n'
    text+='출력·회전수만 사용하는 정상 모델에 실내 온도, 냉각수 입구 온도를 추가하는 후보를 구현했다. 과급압과 흡기 온도는 고장 영향도 받을 수 있어 이번 정상 조건 입력에 넣지 않았다. 기존 정상 학습 내부120초 시각 블록/20초 공백 검증 후에도 오경보가 남아 다른 시험의 고장 주입 전 정상 자료를 추가했다.\n\n'
    text+=f"추가 정상 자료는 학습 **{manifest['added_train_rows']:,}행**, 보정 **{manifest['added_calibration_rows']:,}행**이다. 같은 엔진의 다른 시험6개 파일이며 새 독립 설비 자료가 아니다. AF 평가4개 파일과 기존 Reference 정상 평가4,719행은 변경하지 않았다. 추가 학습3파일과 보정3파일은 서로 겹치지 않으며, 평가 센서 벡터와의 재사용/중복도 검사했다.\n\n"
    text+=tab(['용도','추가 정상 파일'],[
        ['학습','AC_Fouling_40, AC_Fouling_75, Turbine_Degradation_60'],
        ['보정','AC_Fouling_60, Turbine_Degradation_40, Turbine_Degradation_85']])
    text+='\n추가 자료를 포함한 후보는 정상 학습 자료 안에서 **원 실험 파일 전체를 묶은3분할 검증**으로 선택했다. 기준은 정상 예측 오차다. 정상 보정에서 q99.99와 최소 잔차 한계를 정했다. 평가 정상 구간을 보정 자료로 옮기지 않았다. 정상 검증은 환경 변수를 넣은 모델보다 출력·회전수2차식을 선택했다.\n\n'
    text+='절대 차압 오차 후보와 별도로 과거60초 평균 잔차 대비60/300/900초 전 평균 잔차의 증가를 감시하는 경로를 구현했다. 관측 시계·결측·실험 경계를 넘지 않으며 평가 자료로 새로운 기준선을 학습하지 않는다. 이 경로는 상태 변화 감시이고, 시작 시부터 존재하는 정적 막힘을 진단하는 모델은 아니다. 기존 절대 차압 경보와 OR로 결합했다.\n\n'
    text+=table(a['marine']['raw_detection'])
    text+='\n모든 후보를 미채택했다. 긴 창의 정상 추세 영향을 줄이는 fast_change(60초 평균·60초 차이)는 오경보를0.8382%까지 줄였지만 기존0.0294%보다 높고 정확도도 낮았다. growth의 최대 관측 지연이 줄어도 오경보12.45%를 감수하는 개선은 채택하지 않는다. point는 양성 시작 전부터 경보인 구간2개가 있어 지연을 전체4구간의 개선으로 비교하지 않았다. **유지 기준은 baseline이다.**\n\n'
    text+='제공자 정상 구간에서도 차압이 시간에 따라 증가한다. 첫/마지막100표본 중앙값은40% 부하 약98.20→112.43Pa,75%는240.46→271.97Pa,85%는311.05→343.64Pa다. 이를 임의로 고장으로 재표기하지 않았다. 정상 변동, 계측/시험 조건, 조작·정답 시각의 관계는 추가 계측·원 기록으로 확인해야 한다. 단순히 작은 차압 증가에 민감하게 만들면 이 정상 표본에서도 경보한다.\n\n'
    text+='## 2. EF10.1 실제 측정값 기반 추가 판정\n\n'
    text+='처음에는 응축온도를 정상 예측의 조건으로 넣었다. 그러나 EF10.1의 응축온도가 정상 범위를 벗어나 새 경로 판단률이0%가 됐다. 따라서 이 후보는 보류하고, 응축온도를 감시 응답으로 바꿨다. 별도 과열도 로거도 실제 타임스탬프를 이용해 과거5초 이내 관측만 결합해 비교했지만 개선을 만들지 못했고 선택하지 않았다. 보조 로거의 시계 동기·전달 지연은 독립적으로 검증하지 못했다.\n\n'
    text+='선택한 response_point는 명목 부하별 정상 응답을 학습하고 **부하별로 정상 잔차 한계를 보정**한다. 감시 응답은 증발온도·전력·속도·COP와 응축온도다. 새로운 온도 채널을 만들어 넣지 않았다. 최소 온도 편차 기준은0.2K, 로그 응답은0.02이며 이는 **공학적 민감도 설정**으로, 계측 정확도나 신뢰수준을 보증하는 값이 아니다. 정상 보정 경험분포 q99.9와 함께 한계를 정했다. 원시 경로에는30초 지속 확인을 적용하며 해제 지연은 없다.\n\n'
    text+=table({k:a['heatpump']['raw_detection'][k] for k in ['baseline','response_point','response_mean60','without_cond_point']})
    text+='\n전체 평가 대상5,775행(정상490 / 고장5,285), 원시6,405행 기준 판단률은90.1639%로 유지됐다. 대상 중 판단률100%는 원본 전체에 대한100%가 아니다.\n\n'
    weakrows=[]
    for key in ['baseline','response_point','response_mean60','without_cond_point']:
        v=a['heatpump']['raw_detection'][key];m=v['EF10_1_metrics'];d=v['EF10_1_delay']
        weakrows.append([key,pc(m['accuracy_valid']),pc(m['recall_valid']),f"{m['TP']} / {m['FN']}",pc(m['coverage']),str(d['max_delay_s'])+'초'])
    text+=tab(['EF10.1 원시 정책','정확도','검출률','TP / FN','판단률','첫/최대 관측 지연'],weakrows)
    text+='\nEF10.1은 고장 양성163표본뿐이므로 그 부분집합의 오경보율은 산출할 수 없다. 위 전체 정상490표본의 오경보0건을 별도로 사용한다. 지연은 고정180초 제외 후 첫 유효 양성 관측부터이며 독립적인 실제 고장 발생 시각부터의 지연이 아니다. 초기에 새로 검출한 표본이 있으므로 단순 경보 유지와 구별되는 원시 판정 변화다.\n\n'
    text+='### 원인 특이성과 반복성 제한\n\n'
    text+='응축온도 응답을 빼면 EF10.1 검출률은49.08%에 머문다. 해당 정상10.2kW 기록의 응축온도는46.8℃이고 EF10.1은46.5℃다. 이0.3K 차이가 개선을 만든 핵심 단서다. 두 기록은 다른 날짜/시험이므로 **유량 감소 효과와 시험·제어·계측 편차를 현재 자료로 분리하지 못한다.** 따라서 개발 프로파일의 표시 의미는 정상 기준 대비 상태 편차이며, 증발기 유량 감소 확정 진단이 아니다.\n\n'
    sens=a['heatpump']['source_specificity']['sensor_offset_sensitivity']
    text+=tab(['정상 측정 기록에 주입한 응축온도 센서 편차','추가 경로 경보 비율','증거 종류'],[
        [str(x['injected_saturation_temperature_offset_k'])+'K',pc(x['alarm_fraction']),'실측 정상 기록 + 합성 센서 편차'] for x in sens])
    text+='\n편차가 없으면 경보0,±0.3K 편차에서는 대부분 경보했다. 이 시험은 유량 고장에 특이적이지 않은 민감도를 보여 주며, 실제 정상 운전 오경보율이나 새로운 물리 고장 검증에 합산하지 않았다. 다른 날짜 정상 자료와 계측 반복성을 확보하기 전에는 독립 고장 진단 완료로 판정하지 않는다.\n\n'
    text+='## 3. 경보 유지 효과만 별도 비교\n\n'
    text+='아래 검출률 열은 **경보가 활성 상태인 표본 비율**이다. 같은 원시 판단을30/60초 더 유지한 것으로 센서 검출력 개선에 합산하지 않는다.\n\n'
    text+='히트펌프 전체 평가\n\n'+table(a['heatpump']['alarm_policy'])
    rows=[]
    for key,v in a['heatpump']['alarm_policy'].items():
        rows.append([key,pc(v['EF10_1_metrics']['recall_valid']),str(v['EF10_1_delay']['max_delay_s'])+'초'])
    text+='\n'+tab(['정책','EF10.1 경보 유지 비율','첫 관측 지연'],rows)
    text+='\n기존 원시 경보에 유지 정책을 적용하면49.08→54.60/60.12%로 보이지만 최초510초 지연은 그대로다. 새 response_point에는 유지 정책의 추가 이득이 없었다. 고장 복구 구간 정답이 없어서 해제 지연으로 생길 복구 후 오경보는 평가하지 못했다.\n\n'
    text+='엔진 필터의 기존 경보·짧은 창 후보에 유지 정책만 적용\n\n'+table(a['marine']['alarm_policy'])
    text+='\n필터는 유지 정책으로 오경보가0.0294→0.4412/0.7721%로 증가하고 최대 지연은 그대로였다. 양쪽 모두 해제 지연을 기본값으로 채택하지 않았다.\n\n'
    text+='## 구현·검증·재현\n\n'
    text+='- `ConditionalResidualDiagnostic`: 명시적 단위/로그 변환, 정상 회귀, 부하별 정상 보정, 과거 관측만 사용하는 잔차 평균, 운전 범위 검사. observed/expected 응답 지표는 설정한 변환 공간의 값이며 로그 사용 시 원 단위 값과 다르다.\n'
    text+='- `WindowChangeDiagnostic`: 과거 잔차 평균 간 변화량, 정상 자료로만 정한 한계, 결측·운전 구간·시계 간격 초기화.\n'
    text+='- 입력·응답 순서의 JSON 저장/복원 문제를 수정했다. 순서를 설정·모델 양쪽에 명시하며 잘못된 순서는 거부한다. **최종 평가 자체도 저장한 JSON에서 모델을 다시 불러온 뒤 실행했다.**\n'
    text+='- 기존 외부 분리 유지, 추가 정상 파일간 분리 및 평가 센서 벡터 중복0 확인. 후보 선택은 정상 학습 내부 검증, 한계는 별도 정상 보정이다. 이미 관찰한 평가 결과를 바탕으로 후보 구조를 수정한 개발 과정이므로 최종 수치는 재사용 평가로 표시했다. 초기 실패 후보는 initial_context_only와 augmented_context_only에 보존했다.\n'
    text+='- 회귀·물리 시험 **286개**, 기존 객체 연동 **7개** 통과. 새9개 시험은 손계산, 입력·범위·극단값, 부하별 보정, 인과성, 스트리밍 일치, 실패 복구, 정렬된 JSON 복원 순서 등을 다룬다.\n'
    text+=f"- 별도 코드가 원본 정답·시각·동결 기준과 **{audit['independent_prediction_replayed_rows']:,}개 후보 표본의 계산·경보**를 재구성하고, 원시·경보 유지 표를 독립 재집계했다. 이 수는 독립 고장 표본 수가 아니다.\n\n"
    text+='실행: scripts/improve_two_targets.py → scripts/assess_two_targets.py → scripts/audit_two_targets.py → scripts/render_two_targets.py. 새 기능은 Python API이며 기존 CLI 종류11개는 유지했다. 원시 자료와 결과·동결 기준은 소프트웨어 소스 배포본과 별도 보존한다.\n\n'
    text+='## 다음 검증에 필요한 자료\n\n'
    text+='히트펌프는 같은 부하에서 다른 날짜의 정상·약한 유량 감소 반복시험, 응축측 제어 설정 및 센서 반복성 자료가 우선이다. 필터는 평가와 독립된 실제 정상 운전 변동 자료와 가림 조작 시각·차압 변화의 원 기록을 확보해야 한다. 기존 평가 정상 구간을 재학습으로 옮기거나 정답 시각을 바꿔 성능을 높이지 않는다.\n\n'
    text+='출처: [NIST 정상 기준·잔차·불확실성](https://www.nist.gov/publications/cooling-mode-fault-detection-and-diagnosis-method-residential-heat-pump), [원 히트펌프 실험](https://doi.org/10.1016/j.ijrefrig.2021.10.017), [엔진 원자료](https://zenodo.org/records/19857425), [시계열 이동창 변화 검출 연구](https://arxiv.org/abs/1907.05453), [ISA 경보 관리](https://www.isa.org/intech-home/2019/january-february/features/applying-alarm-management). 본 구현은 원리를 적용한 자체 구현이며 해당 논문 알고리즘의 완전 재현은 아니다.\n'
    (ROOT/'docs/TWO_TARGET_IMPROVEMENT.md').write_text(text,encoding='utf-8')
    # Compact standalone review artifact, with raw and held results visually distinct.
    page='<!doctype html><html lang="ko"><meta charset="utf-8"><title>두 항목 보완·검증 v0.16</title><style>body{font:16px/1.65 system-ui;max-width:1500px;margin:32px;color:#173047}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{border:1px solid #c4d0db;padding:10px;text-align:left}th{background:#e7eef5}pre{white-space:pre-wrap;overflow-wrap:anywhere}.note{padding:18px;background:#fff0d3}</style><h1>엔진 필터·EF10.1 보완 및 경보 유지 검증 · v0.16.0</h1><p class="note">기존 실제 평가 재사용. EF10.1의 원시 표본 판별력은 개선됐지만 응축온도 편차에 의존하며 날짜/계측 편차와 원인을 구분하지 못합니다. 엔진 필터 후보는 오경보 증가로 미채택했습니다. 경보 유지 효과는 원시 검출과 분리합니다.</p>'
    def htmltable(title,records):
        h='<h2>'+escape(title)+'</h2><table><tr><th>정책</th><th>정확도</th><th>검출/활성 비율</th><th>오경보율</th><th>대상 판단률</th></tr>'
        return h+''.join('<tr><td>'+escape(k)+'</td>'+''.join('<td>'+pc(v['metrics'][a])+'</td>' for a in ('accuracy_valid','recall_valid','false_positive_rate_valid','coverage'))+'</tr>' for k,v in records.items())+'</table>'
    page+=htmltable('엔진 필터: 원시 판정',a['marine']['raw_detection'])
    page+=htmltable('히트펌프: 원시 판정',{k:a['heatpump']['raw_detection'][k] for k in ['baseline','response_point','response_mean60','without_cond_point']})
    page+=htmltable('히트펌프: 경보 유지 정책',a['heatpump']['alarm_policy'])
    page+=htmltable('필터: 경보 유지 정책',a['marine']['alarm_policy'])
    page+='<details><summary>상세 원문·지연·누락 자료·검증</summary><pre>'+escape(text)+'</pre></details></html>'
    (OUT/'report.html').write_text(page,encoding='utf-8');print('Two-target report written.')
if __name__=='__main__':main()
